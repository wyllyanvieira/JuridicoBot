const client = require('../index');




client.on("", async () => {
    

});